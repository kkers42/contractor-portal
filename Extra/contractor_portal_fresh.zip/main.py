from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordRequestForm
from fastapi.staticfiles import StaticFiles
from auth import verify_password
from db import fetch_query
import os

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/api/login/")
def login(form_data: OAuth2PasswordRequestForm = Depends()):
    user = fetch_query("SELECT * FROM users WHERE email = %s", (form_data.username,))
    if not user or not verify_password(form_data.password, user[0]['password']):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid username or password")
    return {"access_token": "fake-jwt-token", "token_type": "bearer", "role": user[0]["role"]}

@app.post("/debug/test-login/")
def debug_test_login(data: dict):
    from auth import verify_password
    email = data.get("email")
    password = data.get("password")
    user = fetch_query("SELECT * FROM users WHERE email = %s", (email,))
    if not user:
        return {"ok": False, "reason": "❌ No such user"}
    user = user[0]
    result = verify_password(password, user['password'])
    return {
        "ok": result,
        "input_password": password,
        "stored_hash": user['password'],
        "matched": result,
        "role": user['role'],
        "email": user['email']
    }