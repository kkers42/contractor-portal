DELETE FROM users WHERE email = 'admin@test.com';
INSERT INTO users (name, phone, email, role, password)
VALUES ('Admin Test', '555-555-5555', 'admin@test.com', 'Admin', '$2b$12$iAZw7Dt/DqVf0QGRMqYTq.uGTcbmSV/0O20e3/vjebqwTBc14ZESa');