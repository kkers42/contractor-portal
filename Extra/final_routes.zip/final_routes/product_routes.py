# Handles winter and landscape product endpoints
from fastapi import APIRouter
router = APIRouter()
