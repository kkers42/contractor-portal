// config.js

// Automatically detect local vs production environment
const isLocalhost = window.location.hostname.startsWith("127.") || window.location.hostname === "localhost";

const API_BASE_URL = isLocalhost
  ? "http://127.0.0.1:8000"
  : "https://contractor-portal-1074698584693.us-central1.run.app";

// Global headers used in fetch requests (if needed)
const defaultHeaders = {
  "Content-Type": "application/json",
  // Add more default headers if needed
};

// Optional: configuration object
const CONFIG = {
  API_BASE_URL,
  IS_PRODUCTION: !isLocalhost,
  APP_VERSION: "v1.0.0",
};

// Export config if using a module system (optional for future-proofing)
// export { API_BASE_URL, defaultHeaders, CONFIG };
