import mysql.connector
from mysql.connector import Error
from datetime import datetime
import os

DB_CONFIG = {
    "host": os.getenv("DB_HOST"),       # Cloud SQL socket
    "user": os.getenv("DB_USER"),
    "password": os.getenv("DB_PASSWORD"),
    "database": os.getenv("DB_NAME")
}


# DB_CONFIG = {
    # "host": "localhost",
    # "user": "gracej",
    # "password": "Bimmer325i",
    # "database": "contractor_portal",
    # "auth_plugin": "mysql_native_password"
# }

def get_connection():
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        return conn
    except Error as e:
        print(f"Database connection error: {e}")
        return None

def insert_subcontractor(name, email, password, phone):
    conn = get_connection()
    if not conn:
        return False
    try:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO subcontractors (name, email, password, phone)
            VALUES (%s, %s, %s, %s)
        """, (name, email, password, phone))
        conn.commit()
        print("Subcontractor added successfully.")
        return True
    except Error as e:
        print(f"Error inserting subcontractor: {e}")
        return False
    finally:
        cursor.close()
        conn.close()

def insert_location(name, address, sqft, area_manager, plow, salt):
    conn = get_connection()
    if not conn:
        return False
    try:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO locations (name, address, sqft, area_manager, plow, salt)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (name, address, sqft, area_manager, plow, salt))
        conn.commit()
        return True
    except Error as e:
        print(f"Error inserting location: {e}")
        return False
    finally:
        cursor.close()
        conn.close()


def submit_timesheet(subcontractor_id, location_id, time_in, time_out, bulk_salt, bag_salt, calcium_chloride, customer_provided):
    conn = get_connection()
    if not conn:
        return False
    try:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO timesheets (subcontractor_id, location_id, time_in, time_out, bulk_salt, bag_salt, calcium_chloride, customer_provided)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """, (subcontractor_id, location_id, time_in, time_out, bulk_salt, bag_salt, calcium_chloride, customer_provided))
        conn.commit()
        print("Timesheet submitted successfully.")
        return True
    except Error as e:
        print(f"Error submitting timesheet: {e}")
        return False
    finally:
        cursor.close()
        conn.close()

def login_subcontractor(email, password):
    conn = get_connection()
    if not conn:
        return None
    try:
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT id, name FROM subcontractors WHERE email = %s AND password = %s", (email, password))
        user = cursor.fetchone()
        if user:
            print(f"Welcome, {user['name']}!")
            return user
        else:
            print("Invalid credentials.")
            return None
    except Error as e:
        print(f"Error during login: {e}")
        return None
    finally:
        cursor.close()
        conn.close()

def fetch_query(query, params=None):
    """Executes a SELECT query and returns the results."""
    conn = get_connection()
    if not conn:
        return None

    try:
        cursor = conn.cursor(dictionary=True)  # Returns rows as dictionaries
        cursor.execute(query, params or ())
        results = cursor.fetchall()
        cursor.close()
        conn.close()
        return results
    except mysql.connector.Error as e:
        print(f"❌ Fetch query error: {e}")
        return None

def execute_query(query, params=None):
    """Executes a given SQL query (INSERT, UPDATE, DELETE)."""
    conn = get_connection()
    if not conn:
        return False
    
    try:
        cursor = conn.cursor()
        cursor.execute(query, params or ())
        conn.commit()
        cursor.close()
        conn.close()
        return True
    except mysql.connector.Error as e:
        print(f"❌ Query execution error: {e}")
        return False

if __name__ == "__main__":
    # Example usage
    insert_subcontractor("John Doe", "johndoe@example.com", "password123", "123-456-7890")
    insert_location("Site A", "123 Main St", 5000, "Mike Smith", True, True)
    login_subcontractor("johndoe@example.com", "password123")
    submit_timesheet(1, 1, datetime.now(), datetime.now(), 2.5, 10, 5, False)
