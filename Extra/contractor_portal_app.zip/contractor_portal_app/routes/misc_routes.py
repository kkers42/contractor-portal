# Handles email, signup requests, and misc routes
from fastapi import APIRouter
router = APIRouter()
