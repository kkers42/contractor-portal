# Handles green and winter operations logs
from fastapi import APIRouter
router = APIRouter()
