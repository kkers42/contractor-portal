# Handles add/update/delete/fetch property routes
from fastapi import APIRouter
router = APIRouter()
