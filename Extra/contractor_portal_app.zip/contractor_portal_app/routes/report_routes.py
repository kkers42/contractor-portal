# Handles reporting endpoints for products, properties, and users
from fastapi import APIRouter
router = APIRouter()
