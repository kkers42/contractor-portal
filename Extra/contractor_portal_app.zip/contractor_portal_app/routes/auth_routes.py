# Handles login, signup, password reset, and user auth routes
from fastapi import APIRouter
router = APIRouter()
